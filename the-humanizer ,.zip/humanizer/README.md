# The Humanizer

A web app that strips AI writing patterns from your text and rewrites it to sound like a real person wrote it.

Paste in a blog post, email draft, LinkedIn update, or Wikipedia article. Get back a cleaner version — with a breakdown of every pattern that was removed, and a self-audit that catches anything that slipped through.

Built with React + Vite. Powered by the Claude API. Based on [Wikipedia's Signs of AI Writing guide](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing).

---

## What it fixes

The AI writing patterns it hunts down:

- **Significance inflation** — "pivotal moment", "testament to", "underscores its vital role"
- **Promotional language** — "nestled", "vibrant", "breathtaking", "groundbreaking"
- **Superficial -ing endings** — "highlighting...", "showcasing...", "reflecting..."
- **Vague attributions** — "experts say", "industry observers note", "some critics argue"
- **AI vocabulary** — delve, tapestry, synergy, unlock, foster, ensure
- **Rule-of-three structures** — "The tool serves as a catalyst. The assistant functions as a partner. The system stands as a foundation."
- **Em dash overuse** — using `—` to fake profundity
- **Negative parallelism** — "It's not just X; it's Y"
- **Generic positive conclusions** — "The future looks bright. Exciting times lie ahead."
- **Excessive hedging** — "could potentially possibly be argued that it might"
- **Chatbot artifacts** — "Great question!", "I hope this helps!", "Let me know if you'd like me to expand"

---

## Demo

![screenshot placeholder](./public/screenshot.png)

---

## Getting started

### Prerequisites

- Node.js 18+
- An [Anthropic API key](https://console.anthropic.com/)

### Installation

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/the-humanizer.git
cd the-humanizer

# 2. Install dependencies
npm install

# 3. Set up your API key
cp .env.example .env
# Then open .env and replace `your_api_key_here` with your actual key

# 4. Start the dev server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173).

### Build for production

```bash
npm run build
npm run preview
```

The `dist/` folder is ready to deploy to Vercel, Netlify, Cloudflare Pages, or anywhere that serves static files.

---

## Project structure

```
the-humanizer/
├── src/
│   ├── App.jsx        # Main UI component
│   ├── api.js         # Claude API call + humanizer system prompt
│   ├── main.jsx       # React entry point
│   └── index.css      # Base styles and keyframe animations
├── public/
├── index.html
├── vite.config.js
├── .env.example       # Copy this to .env and add your key
└── .gitignore
```

---

## Environment variables

| Variable | Description |
|---|---|
| `VITE_ANTHROPIC_API_KEY` | Your Anthropic API key. Never commit this. |

> **Note:** This app calls the Anthropic API directly from the browser using the `anthropic-dangerous-direct-browser-access` header. This is fine for personal use and demos, but for a production app you should proxy requests through your own backend to keep your API key secret.

---

## Deployment

**Vercel (recommended)**

1. Push to GitHub
2. Import the repo at [vercel.com/new](https://vercel.com/new)
3. Add `VITE_ANTHROPIC_API_KEY` as an environment variable in the Vercel dashboard
4. Deploy

**Netlify**

Same steps — add the env var under Site Settings → Environment Variables.

---

## Credits

- Pattern guide: [Wikipedia:Signs of AI writing](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing), maintained by WikiProject AI Cleanup
- Model: [Claude](https://anthropic.com) by Anthropic

---

## License

MIT
