import { useState, useRef } from "react";
import { humanizeText } from "./api.js";

const EXAMPLE = `Great question! Here is a breakdown of why remote work has become such a transformative shift in the modern professional landscape.

Remote work serves as a testament to the evolving nature of the employer-employee relationship, marking a pivotal moment in how organizations adapt to the rapidly changing demands of the 21st century. It not only enhances flexibility and work-life balance, but also fosters a culture of trust and accountability, underscoring the vital role of autonomy in driving productivity.

Industry experts have noted that companies embracing this groundbreaking model are better positioned to attract top talent. The future looks bright for distributed teams. Exciting times lie ahead as organizations continue their journey toward excellence.

Let me know if you'd like me to expand on any of these points!`;

function wordCount(text) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

export default function App() {
  const [input, setInput]   = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState(null);
  const [copied, setCopied] = useState(false);
  const textareaRef = useRef(null);

  const handleHumanize = async () => {
    const text = input.trim();
    if (!text) return;
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const parsed = await humanizeText(text);
      setResult(parsed);
    } catch (e) {
      setError(e.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (result?.humanized) {
      navigator.clipboard.writeText(result.humanized);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // ─── styles ───────────────────────────────────────────────────────────────

  const s = {
    page: {
      minHeight: "100vh",
      background: "#f5f0e8",
      fontFamily: "Georgia, serif",
      color: "#1a1208",
    },
    wrap: {
      position: "relative",
      zIndex: 1,
      maxWidth: 900,
      margin: "0 auto",
      padding: "0 24px 80px",
    },
    header: {
      paddingTop: 52,
      paddingBottom: 32,
      borderBottom: "2px solid #1a1208",
    },
    titleRow: { display: "flex", alignItems: "baseline", gap: 14 },
    title: { fontSize: 42, fontWeight: 400, letterSpacing: "-0.02em", margin: 0, fontStyle: "italic", lineHeight: 1 },
    version: { fontSize: 11, fontFamily: "monospace", letterSpacing: "0.15em", textTransform: "uppercase", opacity: 0.5, paddingBottom: 3 },
    subtitle: { margin: "10px 0 0", fontSize: 15, opacity: 0.6, fontStyle: "italic", maxWidth: 480 },

    label: { fontSize: 11, fontFamily: "monospace", letterSpacing: "0.15em", textTransform: "uppercase", opacity: 0.4 },

    textarea: {
      width: "100%",
      background: "#ede8df",
      border: "2px solid #1a1208",
      padding: "18px 20px",
      fontSize: 15,
      lineHeight: 1.7,
      fontFamily: "Georgia, serif",
      resize: "vertical",
      outline: "none",
      color: "#1a1208",
    },
    submitBtn: (disabled) => ({
      background: disabled ? "#9e9589" : "#1a1208",
      color: "#f5f0e8",
      border: "none",
      padding: "13px 34px",
      fontSize: 14,
      fontFamily: "Georgia, serif",
      fontStyle: "italic",
      cursor: disabled ? "not-allowed" : "pointer",
      letterSpacing: "0.03em",
      transition: "background 0.2s",
    }),
    verdict: {
      background: "#1a1208",
      color: "#f5f0e8",
      padding: "14px 22px",
      fontSize: 14,
      fontStyle: "italic",
      borderLeft: "4px solid #c4a35a",
      marginBottom: 32,
    },
    col: (before) => ({
      background: before ? "#e8dfd0" : "#f0ece2",
      padding: "20px 22px",
      fontSize: 14,
      lineHeight: 1.75,
      color: before ? "#5a4a30" : "#1a1208",
      borderTop: `3px solid ${before ? "#c4a35a80" : "#2d6a4f"}`,
      minHeight: 200,
      whiteSpace: "pre-wrap",
      wordBreak: "break-word",
    }),
    changeItem: {
      fontSize: 13,
      lineHeight: 1.6,
      padding: "8px 0",
      borderBottom: "1px solid #1a120812",
      display: "flex",
      gap: 10,
    },
  };

  // ─── render ───────────────────────────────────────────────────────────────

  return (
    <div style={s.page}>
      <div style={s.wrap}>

        {/* Header */}
        <header style={s.header}>
          <div style={s.titleRow}>
            <h1 style={s.title}>The Humanizer</h1>
            <span style={s.version}>v2.2</span>
          </div>
          <p style={s.subtitle}>
            Strips the robot out of your writing. Based on Wikipedia's Signs of AI Writing guide.
          </p>
        </header>

        {/* Input */}
        <section style={{ marginTop: 36 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <span style={s.label}>Paste your AI slop here</span>
            <button
              onClick={() => { setInput(EXAMPLE); setResult(null); }}
              style={{ background: "none", border: "1px solid #1a1208", padding: "4px 12px", fontFamily: "monospace", fontSize: 11, letterSpacing: "0.1em", cursor: "pointer", opacity: 0.45, textTransform: "uppercase" }}
            >
              Try example
            </button>
          </div>

          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Paste any AI-generated text — blog posts, emails, LinkedIn posts, Wikipedia drafts…"
            rows={9}
            style={s.textarea}
          />

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 12 }}>
            <span style={{ fontSize: 12, fontFamily: "monospace", opacity: 0.35 }}>
              {input ? `${wordCount(input)} words` : ""}
            </span>
            <button
              onClick={handleHumanize}
              disabled={loading || !input.trim()}
              style={s.submitBtn(loading || !input.trim())}
            >
              {loading ? "Humanizing…" : "Humanize →"}
            </button>
          </div>
        </section>

        {/* Loading */}
        {loading && (
          <div style={{ marginTop: 48, textAlign: "center" }}>
            <div style={{ display: "inline-block", width: 32, height: 32, border: "2px solid #1a120820", borderTop: "2px solid #1a1208", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
            <p style={{ marginTop: 16, fontStyle: "italic", opacity: 0.5, fontSize: 14 }}>Stripping the robot out…</p>
          </div>
        )}

        {/* Error */}
        {error && (
          <div style={{ marginTop: 32, padding: "16px 20px", border: "1px solid #c0392b", background: "#fdf0ee", fontSize: 14, color: "#c0392b" }}>
            {error}
          </div>
        )}

        {/* Result */}
        {result && (
          <div style={{ marginTop: 48, animation: "fadeIn 0.4s ease" }}>

            <div style={s.verdict}>
              <span style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.12em", textTransform: "uppercase", opacity: 0.6, fontStyle: "normal" }}>Verdict — </span>
              {result.verdict}
            </div>

            {/* Side by side */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
              <div>
                <div style={{ ...s.label, marginBottom: 10 }}>Before</div>
                <div style={s.col(true)}>{input}</div>
                <div style={{ fontFamily: "monospace", fontSize: 11, opacity: 0.35, marginTop: 8 }}>{wordCount(input)} words</div>
              </div>
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                  <div style={s.label}>After</div>
                  <button
                    onClick={handleCopy}
                    style={{ background: "none", border: "1px solid #1a120840", padding: "3px 10px", fontFamily: "monospace", fontSize: 10, letterSpacing: "0.1em", cursor: "pointer", color: "#1a1208", textTransform: "uppercase" }}
                  >
                    {copied ? "✓ Copied" : "Copy"}
                  </button>
                </div>
                <div style={s.col(false)}>{result.humanized}</div>
                <div style={{ fontFamily: "monospace", fontSize: 11, opacity: 0.35, marginTop: 8 }}>{wordCount(result.humanized)} words</div>
              </div>
            </div>

            {/* Changes + Audit */}
            <div style={{ marginTop: 36, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
              <div>
                <div style={{ ...s.label, marginBottom: 14 }}>What changed</div>
                <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
                  {result.changes?.map((c, i) => (
                    <li key={i} style={s.changeItem}>
                      <span style={{ color: "#2d6a4f", fontFamily: "monospace", fontWeight: "bold", flexShrink: 0 }}>—</span>
                      <span style={{ opacity: 0.75 }}>{c}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <div style={{ ...s.label, marginBottom: 14 }}>Self-audit</div>
                {result.aiTells?.length > 0 ? (
                  <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
                    {result.aiTells.map((t, i) => (
                      <li key={i} style={s.changeItem}>
                        <span style={{ color: "#c4a35a", fontFamily: "monospace", fontWeight: "bold", flexShrink: 0 }}>△</span>
                        <span style={{ opacity: 0.75 }}>{t}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div style={{ background: "#e8f5ee", border: "1px solid #2d6a4f40", padding: "16px 20px", fontSize: 13, color: "#2d6a4f", fontStyle: "italic" }}>
                    No remaining AI tells found. Good.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        <footer style={{ marginTop: 72, paddingTop: 20, borderTop: "1px solid #1a120830", fontSize: 12, opacity: 0.4, fontFamily: "monospace" }}>
          Based on Wikipedia:Signs of AI Writing · WikiProject AI Cleanup
        </footer>
      </div>
    </div>
  );
}
