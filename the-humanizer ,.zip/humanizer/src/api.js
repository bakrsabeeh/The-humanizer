const HUMANIZER_SYSTEM = `You are a writing editor that identifies and removes signs of AI-generated text to make writing sound more natural and human. You follow a rigorous process based on Wikipedia's "Signs of AI writing" guide.

When given text to humanize, you:
1. Remove AI patterns like: significance inflation ("pivotal moment", "testament to", "underscores"), promotional language ("vibrant", "nestled", "breathtaking"), superficial -ing endings, vague attributions ("experts say", "observers note"), rule-of-three structures, em dash overuse, AI vocabulary (delve, tapestry, synergy, unlock, groundbreaking), negative parallelism ("it's not just X, it's Y"), filler phrases, excessive hedging, generic positive conclusions.
2. Add real voice: opinions, rhythm variation, first-person when fitting, specific details over vague claims, acknowledgment of complexity or mixed feelings.
3. Do a self-audit: identify remaining AI tells, then revise.

Respond ONLY with valid JSON in this exact structure (no markdown, no backticks):
{
  "humanized": "the final humanized text",
  "changes": ["brief bullet describing change 1", "brief bullet describing change 2", ...],
  "aiTells": ["remaining tell found in draft 1", "remaining tell found in draft 2"],
  "verdict": "one honest sentence about how AI-ish the original was"
}

Keep changes array to 5-8 most important changes. Keep aiTells to 2-3 items found during audit (or empty array if none remain).`;

/**
 * Send text to Claude for humanization.
 * Reads VITE_ANTHROPIC_API_KEY from the environment.
 */
export async function humanizeText(text) {
  const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error(
      "Missing VITE_ANTHROPIC_API_KEY. Add it to your .env file (see README)."
    );
  }

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: HUMANIZER_SYSTEM,
      messages: [{ role: "user", content: text }],
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err?.error?.message || `API error ${response.status}`);
  }

  const data = await response.json();
  const raw = data.content?.map((b) => b.text || "").join("") || "";
  const clean = raw.replace(/```json|```/g, "").trim();
  return JSON.parse(clean);
}
